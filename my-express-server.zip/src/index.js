import express from 'express';
import { users } from './users.js';
import { resolveIndexByUserId } from './middleware/resolveIndexByUserId.js';
import { errorHandler } from './middleware/errorHandler.js';
import { validateRegistrationBody, validateUsersQuery } from './middleware/validationHandler.js';

const app = express();
app.use(express.json())

const PORT = process.env.PORT || 3000;

app.post('/register', validateRegistrationBody, (req, res) => {
  res.send('User registered successfully');
})

app.get('/api/users', validateUsersQuery, (req, res) => {

    let { query : {filter, value, sortBy, order, page, limit} } = req;
    page = page || 1;
    limit = limit || 10;

    let filteredUsers = users;

    if (filter && value) {      
      filteredUsers = users.filter(user => user[filter] == value)      
      if (filteredUsers.length == 0) {
        return res.status(204).send();
      }      
    }

    if (sortBy) {
      filteredUsers.sort((a, b) => {        
        if (a[sortBy] < b[sortBy]) return order == 'desc' ? 1 : -1;
        if (a[sortBy] > b[sortBy]) return order == 'desc' ? -1 : 1;
        return 0;
      })
    }

    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + Number(limit);

    filteredUsers = filteredUsers.slice(startIndex, endIndex);
    
    return res.send(filteredUsers);
})

app.get('/api/users/:id', resolveIndexByUserId,  (req, res) => {  
  res.status(200).json(users[req.findUserIndex]);
})

app.post('/api/users', (req, res) => {
  const { body } = req;
  const newUser = { id : users[users.length - 1].id + 1, ...body };  
  users.push(newUser);
  return res.status(201).send(newUser);
})

app.put('/api/users/:id', resolveIndexByUserId, (req, res) => {   
  const { body, params : { id } } = req;
  users[req.findUserIndex] = { "id" : id, ...body };
  return res.status(200).send();
})

app.patch('/api/users/:id', resolveIndexByUserId, (req, res) => {
  const { body } = req;
  users[req.findUserIndex] = { ...users[req.findUserIndex], ...body };
  return res.status(200).send(users[req.findUserIndex]); 
});

app.delete('/api/users/:id', resolveIndexByUserId, (req, res) => {   
  users.splice(req.findUserIndex, 1);
  return res.sendStatus(200)
})

app.use(errorHandler)

app.listen(PORT, () => {
  console.log(`Running on Port ${PORT}`);
})

